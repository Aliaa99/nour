<?php
    include 'controllers/header.php';
?>


<div class="head-address">
    <div class="container">
       <div class="head-details">
            <h2>أشواك طرد الحمام </h2>
            <a href="#">الرئيسية</a><span>/المنتجات</span>
       </div>
    </div>
</div>



<div class="shortcut mt-5 mb-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="img-show">
                    <img class='img-fluid' src="images/003.png" alt="">
                </div>
            </div>
            <div class="col-md-6">
                <div class="description">
                    <p>لدينا أفضل منتجات طارد الحمام نوفرها لكم بجميع الكميات وتلبية لمتطلبات عملائنا في باقي مدن المملكة فاننا نقوم بشحن المنتج لكم مجانا لدينا أفضل منتجات طارد الحمام نوفرها لكم بجميع الكميات وتلبية لمتطلبات عملائنا في باقي مدن المملكة فاننا نقوم بشحن المنتج لكم مجانا لدينا أفضل منتجات طارد الحمام نوفرها لكم بجميع الكميات وتلبية لمتطلبات عملائنا في باقي مدن المملكة فاننا نقوم بشحن المنتج لكم مجانا 
                    لدينا أفضل منتجات طارد الحمام نوفرها لكم بجميع الكميات وتلبية لمتطلبات عملائنا في باقي مدن المملكة فاننا نقوم بشحن المنتج لكم مجانا لدينا أفضل منتجات طارد الحمام نوفرها لكم بجميع الكميات وتلبية لمتطلبات عملائنا في باقي مدن المملكة فاننا نقوم بشحن المنتج لكم مجانا لدينا أفضل منتجات</p>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="products pb-5 pt-5">
    <div class="container">
        <h2 class='text-center mt-4 mb-4 globe'>منتجات أخرى</h2>
        <div class="owl-carousel owl-theme">
            <div class="item">
                <img src="images/005.png" alt="">
                <a href="#">أشواك طرد الحمام</a>
            </div>
            <div class="item">
                <img src="images/005.png" alt="">
                <a href="#">غطاء المكيف الفيبر جلاس</a>
            </div>
            <div class="item">
                <img src="images/005.png" alt="">
                <a href="#">أشواك طرد الحمام</a>
            </div>
            <div class="item">
                <img src="images/005.png" alt="">
                <a href="#">أشواك طرد الحمام</a>
            </div>
        </div>
    </div>
</div>

<?php
include 'controllers/footer.php';
?>
