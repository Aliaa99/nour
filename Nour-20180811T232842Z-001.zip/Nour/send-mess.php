<?php
    include 'controllers/header.php';
?>

<div class="head-address">
    <div class="container">
       <div class="head-details">
            <h2>راسلنا </h2>
            <a href="#">الرئيسية</a>
       </div>
    </div>
</div>


<div class="send-mess my-5">
    <div class="container">
    <h2>ارسل لنا رسالة وسنقوم بالرد فى اسرع وقت</h2>
        <form action="upload.php" class="mt-4" method="post" enctype="multipart/form-data">
           <div class="row">
                <div class="col-sm-10">
                    <div class="col-sm-6">
                        <input type="text" placeholder="الاسم" name="username">
                    </div>
                    <div class="col-sm-6">
                        <input type="email" placeholder="الايميل" name="mail">
                    </div>
                    <div class="col-sm-12 mt-3">
                        <input type="password" name="password" id="">
                    </div>
                    <!-- <div class="col-sm-12 text-center mt-3">
                       <button class="btn px-5 hvr-float-shadow">إرسال الآن</button>
                        <input type="submit">
                    </div> -->
                </div>
            </div>
            <input type="file" name="upload" id="file">
            <input type="submit" name="submit" id="submit">


        </form>


        <!-- <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" name="upload" id="file">
            <input type="submit" name="submit" id="submit">
        </form> -->
    </div>
</div>


<?php
include 'controllers/footer.php';
?>
