<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Nour</title>
    <!-- Bootstrap v4.1.0 -->
    <link rel="stylesheet" href="css/bootstrap-v4.min.css">
    <link rel="stylesheet" href="css/bootstrap-v4-rtl.min.css">
    <!-- Fontawesome v5.0.13 -->
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <!-- Owl Carousel v2.2.1 -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- Animation -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Hover -->
    <link rel="stylesheet" href="css/hover-min.css">
    <!-- Fonts Stylsheet -->
    <link rel="stylesheet" href="fonts/ITC/stylesheet.css">
    <link rel="stylesheet" href="fonts/coco/stylesheet.css">
    <!-- flaticon icons -->
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <!-- Shortcut Icon -->
    <link rel="shortcut icon" href="images/001.png">
    <!-- Styling File -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
    <div class="base-header">
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <ul class='right-side'>
                        <li><span>0545218563</span><i class='flaticon-telephone'></i></li>
                        <li><i class='flaticon-envelope'></i><span>المملكة العربية السعودية</span></li>
                    </ul>
                </div>
                <div class="col-sm-4">
                    <ul class='left-side text-left'>
                        <li><a href="#"><i class='flaticon-google-plus'></i></a></li>
                        <li><a href="#"><i class='flaticon-instagram'></i></a></li>
                        <li><a href="#"><i class='flaticon-twitter'></i></a></li>
                        <li><a href="#"><i class='flaticon-facebook-letter-logo'></i></a></li>
                        <li><a href="#"><img src="images/007.png" alt=""></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="main-haeder">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-2">
                    <a href="index.php" class="logo-img">
                        <img src="images/001.png" alt="">
                    </a>
                </div>
                <div class="col-lg-offset-1 col-sm-8">
                    <ul class="nav list">
                        <li class="nav-item active">
                        <a class="nav-link" href="index.php">الرئيسية</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#">منتجاتنا</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#">أبرز أعمالنا</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#">أضرار الطيور</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#">راسلنا</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="#">تواصل معنا</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- side menu-->
    <div class="side-menu">
        <div class="container">
        <div class="side-menu-header">
            <a href="#side-list" class="open-menu">
                <i class="fas fa-align-justify"></i>
            </a>
            <a href="#" class="logo-img">
                <img src="images/001.png">
            </a>
            </div>
            <div class="menu2 animated fadeInRight" id="side-list">
                <a href="#side-list" class="close-menu">
                <i class="fa fa-times" aria-hidden="true"></i>
                </a>
                <ul class='text-left'>
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about-us.php">الرؤية</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="services.php">خدمات محاسبية</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="consoltation.php">الاستشارات</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="contact-us.php">تواصل معنا</a>
                        </li>
                </ul>
                <div class="social">
                    <ul class="sociallist mt-5">
                        <li class="px-2 hvr-float"><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                        <li class="px-2 hvr-float"><a href="#"><i class="fab fa-instagram"></i></a></li>
                        <li class="px-2 hvr-float"><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li class="px-2 hvr-float"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li class="px-2 hvr-float"><a href="#"><img src="images/003.png" alt=""></a></li>
                    </ul>
                    </div>

            </div>

        </div>
    </div>
</header>
