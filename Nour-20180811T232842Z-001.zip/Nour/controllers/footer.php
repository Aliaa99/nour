<footer>
    
</footer>

<script src="js\jquery.js"></script>
<script src="js\popper.js"></script>
<script src="js\bootstrap4.js"></script>
<script src="js\owl.carousel.min.js"></script>
<script src="js\main.js"></script>
</body>
</html>