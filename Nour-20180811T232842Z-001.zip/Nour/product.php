<?php
    include 'controllers/header.php';
?>


<div class="head-address">
    <div class="container">
       <div class="head-details">
            <h2>المنتجات </h2>
            <a href="#">الرئيسية</a>
       </div>
    </div>
</div>




<div class="products pb-5 pt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <a href="#">
                    <div class="item complet-width hvr-float">
                        <img src="images/005.png" alt="" class="pb-2">
                        <a href="#">أشواك طرد الحمام</a>
                    </div>
                </a>
            </div>


        </div>
    </div>
</div>

<?php
include 'controllers/footer.php';
?>
