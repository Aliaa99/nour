<?php
    include 'controllers/header.php';
?>


<div class="head-address">
    <div class="container">
       <div class="head-details">
            <h2>أضرار الطيور</h2>
            <a href="#">الرئيسية</a>
       </div>
    </div>
</div>



<div class="shortcut mt-5 mb-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="img-show">
                    <img class='img-fluid' src="images/003.png" alt="">
                </div>
            </div>
            <div class="col-md-6">
                <div class="description">
                    <h3>الاضرار التي تسببها الطيور</h3>
                    <ul class="mt-3">
                        <li>مصدر للروائح الكريهة.</li>
                        <li>مصدر للحشرات المختلفة.</li>
                        <li>تخريب الدهانات والحجر والرخام والقرميد.</li>
                        <li>زيادة مصاريف التنظيف والصيانة ومكافحة الحشرات.</li>
                        <li>مصدر للفيروسات والامراض كانفلونزا الطيور - السالمونيلا.</li>
                        <li>مصدر للديدان والحشرات المتعددة ومنها الذبابة الخبيثة وبق الفراش والقراد والفاش.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>


<?php
include 'controllers/footer.php';
?>
