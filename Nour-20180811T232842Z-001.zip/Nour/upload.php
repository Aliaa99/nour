<?php
$dir=dirname(__FILE__)."/uploads/";

   $path=$_FILES['upload']['tmp_name'];
   $name=$_FILES['upload']['name'];
   $size=$_FILES['upload']['size'];
   $error=$_FILES['upload']['error'];
   $type=$_FILES['upload']['type'];
   if ($_POST['submit']){
       move_uploaded_file($path,$dir.$name);
       echo 'أى حاجه';
   } else {
       echo "hi";
   };


   $username=$_POST['username'];
   $password=$_POST['password'];
   echo "name is  $username  password is  $password";
   
 
?>
