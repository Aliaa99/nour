<?php
  $username=$_POST['username'];
  $password=$_POST['password'];
  echo "name is  $username  password is  $password";
  

?>
